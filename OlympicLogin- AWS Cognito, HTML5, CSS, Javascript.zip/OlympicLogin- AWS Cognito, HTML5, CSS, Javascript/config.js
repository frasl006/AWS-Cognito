window._config = {
  cognito:{
    userPoolId:'eu-west-2_hXekDoufL',
    region:'eu-west-2',
    clientId: '5qkcl9usf28j6l5ejc1prj6b1n'
  }
}